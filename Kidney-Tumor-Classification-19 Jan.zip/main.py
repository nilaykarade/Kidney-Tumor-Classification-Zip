from src.kidney_tumor_clf.utils.common import read_yaml

read_yaml("\Kidney-Tumor-Classification\params.yaml")
